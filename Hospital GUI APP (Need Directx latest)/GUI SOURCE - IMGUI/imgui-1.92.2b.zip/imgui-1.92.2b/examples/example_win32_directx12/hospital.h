#include <iostream>
#include <string>
#include <vector>
#include <stack>
#include <queue>
using namespace std;

// ========== ENUMERATIONS ========== //
enum Department {
    CARDIOLOGY,
    NEUROLOGY,
    ORTHOPEDICS,
    PEDIATRICS,
    EMERGENCY,
    GENERAL
};

enum RoomType {
    GENERAL_WARD,
    ICU,
    PRIVATE_ROOM,
    SEMI_PRIVATE
};

// ========== PATIENT CLASS ========== //
class Patient {
private:
    int id;
    string name;
    int age;
    string contact;
    stack<string> medicalHistory;
    queue<string> testQueue;
    bool isAdmitted;
    RoomType roomType;

public:
    Patient(int pid, string n, int a, string c){
      id= pid;
      name = n;
      age = a;
      contact =c;
      isAdmitted=0;
    }
    //Ask about loging in the medical history stack and ask should i write sentences?

    void admitPatient(RoomType type){
      isAdmitted = true;
      roomType = type;
        string roomTypes[4] = {"GENERAL_WARD","ICU","PRIVATE_ROOM","SEMI_PRIVATE"};
      string record = "Patient admitted in " + roomTypes[type];
        medicalHistory.push(record);
    }
    void dischargePatient() {
        isAdmitted = false;
        string dischargeRecord = "Patient is discharged";
        medicalHistory.push(dischargeRecord);
    }
    void addMedicalRecord(string record) {
        medicalHistory.push(record);
    }
    void requestTest(string testName) {
        testQueue.push(testName);
        medicalHistory.push("the patient should perform test: " + testName);
    }
    string performTest() {
        if (testQueue.empty()) {
            return"No tests should be performed";
        }
        else {
            medicalHistory.push("the patient performed test: " + testQueue.front());
            string test = testQueue.front();
            testQueue.pop();
            return test;
        }
    }
    void displayHistory() {
        stack<string> tempStack;
        while (!medicalHistory.empty()) {
            tempStack.push(medicalHistory.top());
            medicalHistory.pop();
        }

        while (!tempStack.empty()) {
            cout<<tempStack.top()<<endl;
            tempStack.pop();
        }
    }

    int getId() {
        return id;
    }
    const std::string& getName() const {
        return name;
    }
    bool getAdmissionStatus() const {
        return isAdmitted;
    }
    RoomType getRoomType() const { return roomType; }
};

// ========== DOCTOR CLASS ========== //
class Doctor {
private:
    int id;
    string name;
    Department department;
    queue<int> appointmentQueue;
    
public:
    Doctor(int did, string n, Department d){
        id = did;
        name = n;
        department = d;
    }
    
    void addAppointment(int patientId){
        appointmentQueue.push(patientId);
        cout << "Patient " << patientId << " Booked with " << name << endl;
    }

    int seePatient(){
        if(appointmentQueue.empty()){
            cout << "No patients in the queue for " << name << endl;
            return -1;
        }
        int patientId = appointmentQueue.front();
        appointmentQueue.pop();
        cout << name << " is now seeing patient " << patientId << endl;
        return patientId;
    }
    
    int getId(){
        return id;
    }

    const std::string& getName() const {
        return name;
    }

    string getDepartment() const {
        switch(department){
            case CARDIOLOGY: return "Cardiology";
            case NEUROLOGY: return "Neurology";
            case ORTHOPEDICS: return "Orthopedics";
            case PEDIATRICS: return "Pediatrics";
            case EMERGENCY: return "Emergency";
            case GENERAL: return "General";
            default: return "Unknown";
        }
    }
};

// ========== HOSPITAL CLASS ========== //
class Hospital {
private:
    vector<Patient> patients;
    vector<Doctor> doctors;
    queue<int> emergencyQueue;
    int patientCounter;
    int doctorCounter;
    
public:
    Hospital()
    {
        patientCounter=0;
        doctorCounter=0;
    }
    vector<Patient>& getPatients() { return patients; }
    const vector<Patient>& getPatients() const { return patients; }
    queue<int> getEmergencyQueue()
    {
        return emergencyQueue;
    }
    vector<Doctor>& getDoctors() { return doctors; }
    const vector<Doctor>& getDoctors() const { return doctors; }

    int registerPatient(string name, int age, string contact)
    {
        patients.push_back(Patient(++patientCounter,name,age,contact));
        cout<<"Successfully added a new patient\n";
        cout<<"======================================"<<endl;
        return patientCounter;
    }
    ///////////////////////////
    int addDoctor(string name, Department dept)
    {
        doctors.push_back(Doctor(++doctorCounter,name,dept));
        cout<<"Successfully added a new doctor\n";
        cout<<"======================================"<<endl;
        return doctorCounter;
    }
    //////////////////////////
    void admitPatient(int patientId, RoomType type)
    {
        if(patients.empty())
        {
            cout<<"No patients found to display"<<endl;
        }        
        else if(patientId<=patients.size()&&patientId>0)
        {
            if(patients[patientId-1].getAdmissionStatus())
            {
                cout<<patients[patientId-1].getName()<<" is already admitted to a room"<<endl;
            }
            else
            {
                patients[patientId-1].admitPatient(type);
                cout<<"Successfully addmited "<<patients[patientId-1].getName()<<" to a room"<<endl;
            }
            
        }
        else
        {
            cout<<"invalid Patient ID"<<endl;            
        }   
        cout<<"======================================"<<endl;
        return; 

    }
    ///////////////////////
    void addEmergency(int patientId)
    {

        if(patientId<=patients.size()&&patientId>0)
        {
            cout<<"Successfully added "<<patients[patientId-1].getName()<<" to emeregency"<<endl;
            emergencyQueue.push(patientId);
        }
        else
        {
            cout<<"invalid Patient ID"<<endl;          
        }    
        cout<<"======================================"<<endl;
        return;

    }
    ///////////////////////
    int handleEmergency() {
        if (emergencyQueue.empty()) 
            {
                cout<<"No Emergency Found"<<endl;
                cout<<"======================================"<<endl;
                return -1;
            }

        int id = emergencyQueue.front();
        emergencyQueue.pop();
        cout << "Emergency Treated: " <<id<<" : "<< patients[id-1].getName() << endl;
        cout<<"======================================"<<endl;
        return id;
    }
    ///////////////////////
    void bookAppointment(int doctorId, int patientId)
    {
        if(doctorId>0&&doctorId<=doctors.size())
        {
            if(patientId<=patients.size()&&patientId>0)
            {
                doctors[doctorId-1].addAppointment(patientId);
                cout << "Successfully reserved appointment for Patient "<< patients[patientId-1].getName() << " with Doctor " << doctors[doctorId-1].getName() << endl;
            }
            else
            {
                cout<<"invalid Patient ID"<<endl;
            }
        }
        else
        {
                cout<<"invalid Doctor ID"<<endl;

        }
        cout<<"======================================"<<endl;
        return;
    }
    ///////////////////////
    void displayPatientInfo(int patientId)
    {
        if(patients.empty())
        {
            cout<<"No patients found to display"<<endl;
        }
        else if(patientId<=patients.size()&&patientId>0)
        {
            cout<<"patient ID: "<<patients[patientId-1].getId()<<endl;
            cout<<"patient Name: "<<patients[patientId-1].getName()<<endl;
            cout<<"patient Admission: "<<patients[patientId-1].getAdmissionStatus()<<endl;
            cout<<"patient Medical History:";
            patients[patientId-1].displayHistory();
        }
        else
        {
            cout<<"this ID isn't Valid, Please enter a Valid ID"<<endl;
        }
        cout<<"======================================"<<endl;
        return;
    }
    ///////////////////////
    void displayDoctorInfo(int doctorId)
    {
        if(doctors.empty())
        {
            cout<<"No doctors found to display"<<endl;
        }
        else if(doctorId<=doctors.size()&&doctorId>0)
        {
            cout<<"Doctor ID: "<<doctors[doctorId-1].getId()<<endl;
            cout<<"Doctor Name: "<<doctors[doctorId-1].getName()<<endl;
            cout<<"Doctor Department: "<<doctors[doctorId-1].getDepartment()<<endl;
        }
        else
        {
            cout<<"this ID isn't Valid, Please enter a Valid ID"<<endl;
        }
        cout<<"======================================"<<endl;
        return;
    }
    ///////////////////////
};
